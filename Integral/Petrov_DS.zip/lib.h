#ifndef LIB_H
#define LIB_H

double integral(double, double, double(double));
double divide(double, double, double(double), double);

#endif //  LIB_H