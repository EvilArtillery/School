#ifndef LIB_H
#define LIB_H

double integral(double, double, double(double), double, double);
int divide(double, double, double(double), double);
int unite(double, double, double, double(double));

#endif //  LIB_H